<?php
namespace App\Filament\Widgets;

use App\Models\Forecast\ForecastTraining;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class ForecastStats extends BaseWidget
{
    // Mengambil data dari sesi atau event bus untuk sinkronisasi
    protected function getStats(): array
    {
        // Ambil ID dari sesi atau event yang dipancarkan dari Page
        $productId = session()->get('forecast_product_id');

        $training = ForecastTraining::where('product_id', $productId)->where('is_active', true)->first();

        return [
            Stat::make('Alpha', $training?->alpha ?? '-'),
            Stat::make('Beta', $training?->beta ?? '-'),
            Stat::make('MAPE', isset($training->mape) ? number_format($training->mape, 2) . '%' : '-'),
        ];
    }
}