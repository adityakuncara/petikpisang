<?php

namespace App\Filament\Widgets;

use App\Models\Forecast\ForecastTraining;
use App\Models\Master\Product;
use Filament\Widgets\ChartWidget;

class ForecastChart extends ChartWidget
{
    public ?string $heading = null; // Biar kita set di getHeading()
    protected int|string|array $columnSpan = 'full';

    // 1. Mengambil data langsung dari session (paling stabil)
    protected function getData(): array
    {
        $productId = session()->get('forecast_product_id');
        
        $training = ForecastTraining::where('product_id', $productId)
            ->where('is_active', true)
            ->first();
        
        $results = $training?->results()->orderBy('period_date')->get() ?? collect();

        return [
            'datasets' => [
                ['label' => 'Actual', 'data' => $results->pluck('actual')->toArray(), 'borderColor' => '#3b82f6', 'tension' => 0.3],
                ['label' => 'Forecast', 'data' => $results->pluck('forecast')->toArray(), 'borderColor' => '#f59e0b', 'borderDash' => [5, 5], 'tension' => 0.3]
            ],
            'labels' => $results->pluck('period_date')->map(fn($d) => $d->format('M Y'))->toArray(),
        ];
    }

    // 2. Judul Dinamis berdasarkan produk di session
    public function getHeading(): string
    {
        $productId = session()->get('forecast_product_id');
        $product = Product::find($productId);
        return $product ? 'Grafik Actual vs Forecast: ' . $product->name : 'Grafik Actual vs Forecast';
    }

    // 3. Opsi Skala 100
    protected function getOptions(): array
    {
        return [
            'scales' => ['y' => ['ticks' => ['stepSize' => 100]]],
        ];
    }

    protected function getType(): string { return 'line'; }
}